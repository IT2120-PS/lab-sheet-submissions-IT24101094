setwd("C:\\Users\\IT24101094\\Desktop\\IT24101094")

--1)
branch_data<-read.csv("DATA 4.txt",header = TRUE)
head(branch_data)
            
--2)
str(branch_data)

--3)
boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales",
        ylab = "sales")

--4)
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

--5)
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR_value
  upper <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower | x > upper]
  return(outliers)
}
find_outliers(branch_data$Years_X3)



                